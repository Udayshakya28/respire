import {SurfaceAreaView} from 'react-native'

export default function RootLayout() {
    return (
         <SurfaceAreaView>
            
         </SurfaceAreaView>
    )
  }
  