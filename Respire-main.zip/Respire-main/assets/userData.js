const Users = [
  {
    user_id: "user",
    password: "user@123",
    name: "Samyak Jain",
    gender: "Male",
  },
  {
    user_id: "priyansh",
    password: "user@123",
    name: "Priyansh Singh",
    gender: "Male",
  },
  {
    user_id: "anand",
    password: "user@123",
    name: "Anand Jaiswal",
    gender: "Male",
  },
  {
    user_id: "swarnima",
    password: "user@123",
    name: "Swarnima",
    gender: "Female",
  },
  {
    user_id: "priyanshu",
    password: "user@123",
    name: "Priyanshu Bujethia",
    gender: "Male",
  },
  {
    user_id: "arnav",
    password: "user@123",
    name: "Arnav Goyal",
    gender: "Male",
  },
];

export default Users;
